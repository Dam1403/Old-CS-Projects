import java.util.ArrayList;

public class Vertex{


  public int id;
  public int pred = -1;
  public boolean visited = false;
  public boolean queued = false;
  private ArrayList<Vertex> edges;
  private ArrayList<Integer> weights;
  private int edgesSize = 0;

  public Vertex(int id){
    this.id = id;
    edges = new ArrayList<Vertex>();
  }

  public void addEdge(Vertex edge,int weight){

    for(int i = 0; i < edgesSize; i++){
      //MUST BE REVERSE ORDERED SO THEY CAN BE PUSHED ONTO THE STACK
      if(edge.id > edges.get(i).id){
        edges.add(i, edge);
        break;
      }
      else if(i == edgesSize - 1){
        edges.add(edge);
      }

    }
    if (edgesSize ==0){
      edges.add(edge);
    }
    edgesSize += 1;

  }

  public ArrayList<Vertex> getEdges(){
    return edges;
  }

  public ArrayList<Integer> getWeights(){
    return weights;
  }

  public String toString(){
    String str = "Vertex " + id;

    return str;

  }


}
